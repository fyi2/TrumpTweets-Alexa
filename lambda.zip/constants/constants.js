var constants = Object.freeze({

  appId : '',
  dynamoDBTableName : 'POTUS',

  // Skill States
  states : {
    ONBOARDING : '',
    MAIN : '_MAIN'
  }

});

module.exports = constants;
