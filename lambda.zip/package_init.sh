npm install alexa-sdk
npm install ssml-builder
#npm install yarn -g
#npm install lambda-local -g
#npm install node-gyp -g
npm install request
npm install request-promise
# npm install twit-promise
npm install --save dev chai
npm install --save-dev mocha
npm install --save-dev alexa-skill-test
npm install --save-dev bespoken-tools
npm install --save-dev alexa-conversation
npm ls
