const data = [
  { "adjective" : "big" , "points" : "1"},
  { "adjective" : "bigly" , "points" : "1"},
  { "adjective" : "huge" , "points" : "2"},
  { "adjective" : "classy" , "points" : "3"},
  { "adjective" : "great" , "points" : "4"},
  { "adjective" : "believable" , "points" : "5"},
  { "adjective" : "beautiful" , "points" : "6"},
  { "adjective" : "winning" , "points" : "7"},
  { "adjective" : "amazing" , "points" : "8"},
  { "adjective" : "awesome" , "points" : "8"},
  { "adjective" : "tremendous" , "points" : "9"},
  { "adjective" : "terrific" , "points" : "10"},
  { "adjective" : "incredible" , "points" : "11"}
]

module.exports = data ;
